<html>
    <head>
        <title> TUGAS PSE</title>
        <link rel="stylesheet" href="style2.css">
        
    </head>
    <body>
        <div class="wrapper1">
            <center>
            <header>
                <h5>Tugas PSE</h5>
                <h2>METODE HITUNG DEPRESIASI</h2>
            </header>
            </center>
            <nav>
                <ul>
                    Hazim Khoirudin (L200190105)
                </ul>
                <ul>
                    Surya Apriatama (L200190115)
                </ul>
            </nav>
            <div class="wrapper">
            <center><p><b><font size="17">Metode Hitung</font></b></p></center></br></br></br>
            <center><a href="straight_line.php"><font size="5" color="red">Straight Line</font></a></br></br>
            <a href="reducing_balance.php"><font size="5" color="red">Reducing Balance</font></a></br></br>
            <a href="sum_of_the_year.php"><font size="5" color="red">Sum of The Year</font></a></br></br>
            <a href="unit_of_activity.php"><font size="5" color="red">Unit of Activity</font></a></br></br></center>
</div>
    </body>
</html>